from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/results', methods=['POST'])
def process():
    name = request.form['name']
    locat = request.form['locat']
    favLang = request.form['favLang']
    optionalText = request.form['optionalText']
    return render_template('result.html', name = name, locat = locat, favLang = favLang, optionalText = optionalText)

app.run(debug=True)
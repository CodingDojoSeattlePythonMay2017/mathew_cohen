# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

def index(request):
    data = {
        'title': "No ninjas here"
    }
    return render(request, 'disNinjas/index.html', data)

def ninjas(request):
    data = {
        'title': "Here are some ninjas",
        'ninjas': True
    }
    return render(request, 'disNinjas/index.html', data)

def color(request, color):
    imgSrc = ''
    name = 'Not a April'

    if color == 'red':
        name = 'Raphael'
    if color == 'blue':
        name = 'Leonardo'
    if color == 'orange':
        name = 'Michaelangelo'
    if color == 'purple':
        name = 'Donatello'
    
    if color == 'blue' or color == 'red' or color == 'orange' or color == 'purple':
        imgSrc = color
        title = "You found {}!".format(name)
    else:
        imgSrc = "april"
        title = "You didn't find a ninja, instead you found April!"
        

    print imgSrc

    print name
    
    data = {
        'title': title,
        'img': imgSrc,
        'name': name
    }
    return render(request, 'disNinjas/ninjas.html', data)
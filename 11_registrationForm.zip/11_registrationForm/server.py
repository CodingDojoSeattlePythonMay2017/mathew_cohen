from flask import Flask, render_template, request, redirect, session, flash
import re
app = Flask(__name__)
app.secret_key = 'fff'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/results', methods=['POST'])
def process():
    NAME_REGEX = re.compile(r'\d')
    EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
    errors = 0

    session['firstname'] = request.form['firstname']
    session['lastname'] = request.form['lastname']
    session['email'] = request.form['email']
    session['pass1'] = request.form['pass1']
    session['pass2'] = request.form['pass2']

    if session['firstname'] == '' or session['lastname'] == '' or session['email'] == '' or session['pass1'] == '':
        flash("All fields must be filled in.")
        return redirect('/')
    if NAME_REGEX.search(session['firstname']):
        flash("Your first name doesn't have any numbers in it... stop being dumb.")
        errors += 1
    if NAME_REGEX.search(session['lastname']):
        flash("Your last name doesn't have any numbers in it... stop being dumb.")
        errors += 1
    if not EMAIL_REGEX.match(session['email']):
        flash("That is NOT a valid email... come on...")
        errors += 1
    if session['pass1'] == '':
        flash("You're gonna need a password to register...")
        errors += 1
    if session['pass1'] != session['pass2']:
        flash("Typed passwords don't match.")
        errors += 1
    if len(session['pass1']) > 8:
        flash("Password cannot exceed 8 characters")
        errors += 1
    
    if errors == 0:
        flash("Thanks for registering!")
        return redirect('/results')
    else:
        return redirect('/')

@app.route('/results')
def results():
    return render_template('result.html')

@app.route('/reset')
def reset():
    session.clear()
    return redirect('/')

app.run(debug=True)